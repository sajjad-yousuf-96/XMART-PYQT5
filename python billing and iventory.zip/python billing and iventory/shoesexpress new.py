#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'shoesexpress.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from random import randint
from PyQt5.QtPrintSupport import *
import sys
import sqlite3
import time
import os
sum1=0

class Ui_shop(object):
    def setupUi(self, shop):
        shop.setObjectName("shop")
        shop.resize(968, 600)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/newPrefix/42858739_2161943660497121_6257196708032151552_n.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        shop.setWindowIcon(icon)
        shop.setStyleSheet("color: rgb(255, 255, 255);")
        self.centralwidget = QtWidgets.QWidget(shop)
        self.centralwidget.setObjectName("centralwidget")
        self.mainwidget = QtWidgets.QStackedWidget(self.centralwidget)
        self.mainwidget.setGeometry(QtCore.QRect(-20, 0, 991, 611))
        self.mainwidget.setStyleSheet("background-image: url(:/newPrefix/download 222.png);")
        self.mainwidget.setFrameShape(QtWidgets.QFrame.Box)
        self.mainwidget.setObjectName("mainwidget")
        self.login = QtWidgets.QWidget()
        self.login.setObjectName("login")
        self.widget = QtWidgets.QWidget(self.login)
        self.widget.setGeometry(QtCore.QRect(370, 250, 391, 191))
        self.widget.setStyleSheet("background-image: url(:/newPrefix/download (1).png);")
        self.widget.setObjectName("widget")
        self.userline = QtWidgets.QLineEdit(self.widget)
        self.userline.setGeometry(QtCore.QRect(210, 30, 141, 31))
        self.userline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 16pt \"Times New Roman\";")
        self.userline.setObjectName("userline")
        self.user = QtWidgets.QLabel(self.widget)
        self.user.setGeometry(QtCore.QRect(50, 30, 81, 31))
        self.user.setStyleSheet("font: 75 14pt \"Times New Roman\";\n"
"color: rgb(255, 85, 0);")
        self.user.setObjectName("user")
        self.password = QtWidgets.QLabel(self.widget)
        self.password.setGeometry(QtCore.QRect(30, 80, 101, 31))
        self.password.setStyleSheet("font: 75 14pt \"Times New Roman\";\n"
"color: rgb(255, 85, 0);")
        self.password.setObjectName("password")
        self.passline = QtWidgets.QLineEdit(self.widget)
        self.passline.setGeometry(QtCore.QRect(210, 80, 141, 31))
        self.passline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.passline.setEchoMode(QtWidgets.QLineEdit.Password)
        self.passline.setObjectName("passline")
        self.LOGINButton = QtWidgets.QPushButton(self.widget)
        self.LOGINButton.setGeometry(QtCore.QRect(120, 140, 151, 31))
        self.LOGINButton.setStyleSheet("color: rgb(255, 85, 0);\n"
"background-color: rgb(255, 85, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.LOGINButton.setObjectName("LOGINButton")
        self.mainlabel = QtWidgets.QLabel(self.login)
        self.mainlabel.setGeometry(QtCore.QRect(490, 200, 161, 31))
        self.mainlabel.setStyleSheet("color: rgb(0, 0, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.mainlabel.setObjectName("mainlabel")
        self.frame = QtWidgets.QFrame(self.login)
        self.frame.setGeometry(QtCore.QRect(60, 40, 141, 141))
        self.frame.setStyleSheet("background-image: url(:/newPrefix/42858739_2161943660497121_6257196708032151552_n.jpg);")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label = QtWidgets.QLabel(self.login)
        self.label.setGeometry(QtCore.QRect(410, 20, 291, 41))
        self.label.setStyleSheet("font: 75 18pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 0, 0);")
        self.label.setObjectName("label")
        self.mainwidget.addWidget(self.login)
        self.main = QtWidgets.QWidget()
        self.main.setObjectName("main")
        self.label_2 = QtWidgets.QLabel(self.main)
        self.label_2.setGeometry(QtCore.QRect(270, 50, 291, 71))
        self.label_2.setStyleSheet("font: 75 24pt \"Times New Roman\";")
        self.label_2.setObjectName("label_2")
        self.BILLbutton = QtWidgets.QPushButton(self.main)
        self.BILLbutton.setGeometry(QtCore.QRect(150, 210, 181, 61))
        self.BILLbutton.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 22pt \"Times New Roman\";")
        self.BILLbutton.setObjectName("BILLbutton")
        self.INVENTORYbutton = QtWidgets.QPushButton(self.main)
        self.INVENTORYbutton.setGeometry(QtCore.QRect(500, 210, 181, 61))
        self.INVENTORYbutton.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 22pt \"Times New Roman\";")
        self.INVENTORYbutton.setObjectName("INVENTORYbutton")
        self.pushButton = QtWidgets.QPushButton(self.main)
        self.pushButton.setGeometry(QtCore.QRect(770, 50, 131, 41))
        self.pushButton.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 22pt \"Times New Roman\";")
        self.pushButton.setObjectName("pushButton")
        self.mainwidget.addWidget(self.main)
        self.inventory = QtWidgets.QWidget()
        self.inventory.setObjectName("inventory")
        self.lbid = QtWidgets.QLabel(self.inventory)
        self.lbid.setGeometry(QtCore.QRect(60, 170, 71, 41))
        self.lbid.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.lbid.setObjectName("lbid")
        self.lbname = QtWidgets.QLabel(self.inventory)
        self.lbname.setGeometry(QtCore.QRect(60, 240, 181, 41))
        self.lbname.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.lbname.setObjectName("lbname")
        self.lbquantity = QtWidgets.QLabel(self.inventory)
        self.lbquantity.setGeometry(QtCore.QRect(60, 380, 181, 41))
        self.lbquantity.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.lbquantity.setObjectName("lbquantity")
        self.lbcost = QtWidgets.QLabel(self.inventory)
        self.lbcost.setGeometry(QtCore.QRect(60, 310, 181, 41))
        self.lbcost.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.lbcost.setObjectName("lbcost")
        self.pridline = QtWidgets.QLineEdit(self.inventory)
        self.pridline.setGeometry(QtCore.QRect(280, 160, 241, 61))
        self.pridline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.pridline.setObjectName("pridline")
        self.nameline = QtWidgets.QLineEdit(self.inventory)
        self.nameline.setGeometry(QtCore.QRect(280, 230, 241, 61))
        self.nameline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.nameline.setObjectName("nameline")
        self.costline = QtWidgets.QLineEdit(self.inventory)
        self.costline.setGeometry(QtCore.QRect(280, 300, 241, 61))
        self.costline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.costline.setObjectName("costline")
        self.quanline = QtWidgets.QLineEdit(self.inventory)
        self.quanline.setGeometry(QtCore.QRect(280, 370, 241, 61))
        self.quanline.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.quanline.setObjectName("quanline")
        self.invlb = QtWidgets.QLabel(self.inventory)
        self.invlb.setGeometry(QtCore.QRect(260, 30, 141, 61))
        self.invlb.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";\n"
"\n"
"text-decoration: underline;")
        self.invlb.setObjectName("invlb")
        self.inventorytable = QtWidgets.QTableWidget(self.inventory)
        self.inventorytable.setGeometry(QtCore.QRect(550, 110, 411, 321))
        self.inventorytable.setStyleSheet("\n"
"color: rgb(0, 0, 0);\n"
"background-image: url(:/newPrefix/download.png);")
        self.inventorytable.setObjectName("inventorytable")
        self.inventorytable.setColumnCount(4)
        self.inventorytable.setRowCount(7)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setVerticalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.inventorytable.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        brush = QtGui.QBrush(QtGui.QColor(255, 255, 255))
        brush.setStyle(QtCore.Qt.NoBrush)
        item.setForeground(brush)
        self.inventorytable.setItem(0, 1, item)
        self.addinvent = QtWidgets.QPushButton(self.inventory)
        self.addinvent.setGeometry(QtCore.QRect(120, 490, 75, 31))
        self.addinvent.setStyleSheet("font: 75 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 0, 0);")
        self.addinvent.setObjectName("addinvent")
        self.updateinvent = QtWidgets.QPushButton(self.inventory)
        self.updateinvent.setGeometry(QtCore.QRect(240, 490, 75, 31))
        self.updateinvent.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";")
        self.updateinvent.setObjectName("updateinvent")
        self.deleteinvent = QtWidgets.QPushButton(self.inventory)
        self.deleteinvent.setGeometry(QtCore.QRect(370, 490, 71, 31))
        self.deleteinvent.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";")
        self.deleteinvent.setObjectName("deleteinvent")
        self.loadinvent = QtWidgets.QPushButton(self.inventory)
        self.loadinvent.setGeometry(QtCore.QRect(690, 480, 101, 31))
        self.loadinvent.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 12pt \"MS Shell Dlg 2\";")
        self.loadinvent.setObjectName("loadinvent")
        self.inventBack = QtWidgets.QToolButton(self.inventory)
        self.inventBack.setGeometry(QtCore.QRect(70, 60, 61, 41))
        self.inventBack.setText("")
        self.inventBack.setArrowType(QtCore.Qt.LeftArrow)
        self.inventBack.setObjectName("inventBack")
        self.mainwidget.addWidget(self.inventory)
        self.page = QtWidgets.QWidget()
        self.page.setObjectName("page")
        self.billback = QtWidgets.QToolButton(self.page)
        self.billback.setGeometry(QtCore.QRect(50, 30, 51, 51))
        self.billback.setAutoRaise(False)
        self.billback.setArrowType(QtCore.Qt.LeftArrow)
        self.billback.setObjectName("billback")
        self.cusedit = QtWidgets.QLineEdit(self.page)
        self.cusedit.setGeometry(QtCore.QRect(130, 160, 161, 31))
        self.cusedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.cusedit.setObjectName("cusedit")
        ###################################################
        self.billedit = QtWidgets.QLineEdit(self.page)
        self.billedit.setGeometry(QtCore.QRect(130, 115, 161, 31))
        self.billedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.billedit.setObjectName("billedit")
        #############################################
        self.addressedit = QtWidgets.QLineEdit(self.page)
        self.addressedit.setGeometry(QtCore.QRect(410, 110, 251, 81))
        self.addressedit.setMouseTracking(True)
        self.addressedit.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.addressedit.setAutoFillBackground(False)
        self.addressedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 10pt \"Times New Roman\";")
        self.addressedit.setInputMask("")
        self.addressedit.setText("")
        self.addressedit.setFrame(True)
        self.addressedit.setCursorPosition(0)
        self.addressedit.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.addressedit.setDragEnabled(False)
        self.addressedit.setPlaceholderText("")
        self.addressedit.setCursorMoveStyle(QtCore.Qt.LogicalMoveStyle)
        self.addressedit.setClearButtonEnabled(False)
        self.addressedit.setObjectName("addressedit")
        self.phoneedit = QtWidgets.QLineEdit(self.page)
        self.phoneedit.setGeometry(QtCore.QRect(130, 210, 161, 31))
        self.phoneedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.phoneedit.setObjectName("phoneedit")
        self.billno = QtWidgets.QLabel(self.page)
        self.billno.setGeometry(QtCore.QRect(30, 110, 61, 31))
        self.billno.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.billno.setObjectName("billno")
        self.cusname = QtWidgets.QLabel(self.page)
        self.cusname.setGeometry(QtCore.QRect(30, 160, 91, 31))
        self.cusname.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.cusname.setObjectName("cusname")
        self.address = QtWidgets.QLabel(self.page)
        self.address.setGeometry(QtCore.QRect(320, 110, 71, 31))
        self.address.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.address.setObjectName("address")
        self.phone = QtWidgets.QLabel(self.page)
        self.phone.setGeometry(QtCore.QRect(30, 210, 91, 31))
        self.phone.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.phone.setObjectName("phone")
        self.billing = QtWidgets.QLabel(self.page)
        self.billing.setGeometry(QtCore.QRect(423, 30, 151, 41))
        self.billing.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 28pt \"Times New Roman\";")
        self.billing.setObjectName("billing")
        self.dateedit = QtWidgets.QLineEdit(self.page)
        self.dateedit.setGeometry(QtCore.QRect(410, 210, 191, 31))
        self.dateedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.dateedit.setObjectName("dateedit")
        self.date = QtWidgets.QLabel(self.page)
        self.date.setGeometry(QtCore.QRect(320, 210, 41, 31))
        self.date.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.date.setObjectName("date")
        self.billpr = QtWidgets.QLabel(self.page)
        self.billpr.setGeometry(QtCore.QRect(30, 270, 61, 31))
        self.billpr.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.billpr.setObjectName("billpr")
        self.billpredit = QtWidgets.QLineEdit(self.page)
        self.billpredit.setGeometry(QtCore.QRect(130, 270, 111, 31))
        self.billpredit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.billpredit.setObjectName("billpredit")
        self.billnameedit = QtWidgets.QLineEdit(self.page)
        self.billnameedit.setGeometry(QtCore.QRect(370, 270, 121, 31))
        self.billnameedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.billnameedit.setObjectName("billnameedit")
        self.billname = QtWidgets.QLabel(self.page)
        self.billname.setGeometry(QtCore.QRect(270, 270, 71, 31))
        self.billname.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.billname.setObjectName("billname")
        self.quantityedit = QtWidgets.QLineEdit(self.page)
        self.quantityedit.setGeometry(QtCore.QRect(850, 270, 121, 31))
        self.quantityedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.quantityedit.setObjectName("quantityedit")
        self.billpriceedit = QtWidgets.QLineEdit(self.page)
        self.billpriceedit.setGeometry(QtCore.QRect(590, 270, 111, 31))
        self.billpriceedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.billpriceedit.setObjectName("billpriceedit")
        self.quantity = QtWidgets.QLabel(self.page)
        self.quantity.setGeometry(QtCore.QRect(750, 270, 71, 31))
        self.quantity.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.quantity.setObjectName("quantity")
        self.billprice = QtWidgets.QLabel(self.page)
        self.billprice.setGeometry(QtCore.QRect(510, 270, 61, 31))
        self.billprice.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.billprice.setObjectName("billprice")
        self.additem = QtWidgets.QPushButton(self.page)
        self.additem.setGeometry(QtCore.QRect(380, 340, 61, 41))
        self.additem.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 26pt \"MS Shell Dlg 2\";")
        self.additem.setObjectName("additem")
        self.totalitem = QtWidgets.QPushButton(self.page)
        self.totalitem.setGeometry(QtCore.QRect(460, 480, 75, 41))
        self.totalitem.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 28pt \"MS Shell Dlg 2\";")
        self.totalitem.setObjectName("totalitem")
        self.add1item = QtWidgets.QPushButton(self.page)
        self.add1item.setGeometry(QtCore.QRect(460, 340, 150, 41))
        self.add1item.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 20pt \"MS Shell Dlg 2\";")
        self.add1item.setObjectName("add1item")
        self.grandedit = QtWidgets.QLineEdit(self.page)
        self.grandedit.setGeometry(QtCore.QRect(400, 410, 141, 31))
        self.grandedit.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 18pt \"Times New Roman\";")
        self.grandedit.setText("")
        self.grandedit.setObjectName("grandedit")
        self.grandtotal = QtWidgets.QLabel(self.page)
        self.grandtotal.setGeometry(QtCore.QRect(260, 410, 131, 31))
        self.grandtotal.setStyleSheet("color: rgb(0, 0, 0);\n"
"font: 75 14pt \"Times New Roman\";")
        self.grandtotal.setObjectName("grandtotal")
        self.mainwidget.addWidget(self.page)
        shop.setCentralWidget(self.centralwidget)

        self.retranslateUi(shop)
        self.mainwidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(shop)

    def retranslateUi(self, shop):
        _translate = QtCore.QCoreApplication.translate
        shop.setWindowTitle(_translate("shop", "shoesexpress.pk"))
        self.user.setText(_translate("shop", "USER ID"))
        self.password.setText(_translate("shop", "PASSWORD"))
        self.LOGINButton.setText(_translate("shop", "LOGIN"))
        self.mainlabel.setText(_translate("shop", "shoesexpress.pk"))
        self.label.setText(_translate("shop", "MADE BY MSY SOFTWARE"))
        self.label_2.setText(_translate("shop", "WELCOME BACK!!!"))
        self.BILLbutton.setText(_translate("shop", "BILLING "))
        self.INVENTORYbutton.setText(_translate("shop", "INVENTORY"))
        self.pushButton.setText(_translate("shop", "LOGOUT"))
        self.lbid.setText(_translate("shop", "PR_ID"))
        self.lbname.setText(_translate("shop", "PR_NAME"))
        self.lbquantity.setText(_translate("shop", "PR_QUANTITY"))
        self.lbcost.setText(_translate("shop", "PR_COST"))
        self.invlb.setText(_translate("shop", "INVENTORY"))
        item = self.inventorytable.verticalHeaderItem(0)
        item.setText(_translate("shop", "1"))
        item = self.inventorytable.verticalHeaderItem(1)
        item.setText(_translate("shop", "2"))
        item = self.inventorytable.verticalHeaderItem(2)
        item.setText(_translate("shop", "3"))
        item = self.inventorytable.verticalHeaderItem(3)
        item.setText(_translate("shop", "4"))
        item = self.inventorytable.verticalHeaderItem(4)
        item.setText(_translate("shop", "5"))
        item = self.inventorytable.verticalHeaderItem(5)
        item.setText(_translate("shop", "6"))
        item = self.inventorytable.verticalHeaderItem(6)
        item.setText(_translate("shop", "7"))
        item = self.inventorytable.horizontalHeaderItem(0)
        item.setText(_translate("shop", "PR_ID"))
        item = self.inventorytable.horizontalHeaderItem(1)
        item.setText(_translate("shop", "PR_NAME"))
        item = self.inventorytable.horizontalHeaderItem(2)
        item.setText(_translate("shop", "PR_QUANTITY"))
        item = self.inventorytable.horizontalHeaderItem(3)
        item.setText(_translate("shop", "PR_PRICE"))
        __sortingEnabled = self.inventorytable.isSortingEnabled()
        self.inventorytable.setSortingEnabled(False)
        self.inventorytable.setSortingEnabled(__sortingEnabled)
        self.addinvent.setText(_translate("shop", "ADD"))
        self.updateinvent.setText(_translate("shop", "UPDATE"))
        self.deleteinvent.setText(_translate("shop", "DELETE"))
        self.loadinvent.setText(_translate("shop", "LOAD DATA"))
        self.billback.setText(_translate("shop", "..."))
        self.billno.setText(_translate("shop", "Bill No"))
        self.cusname.setText(_translate("shop", "Cust Name"))
        self.address.setText(_translate("shop", "Address"))
        self.phone.setText(_translate("shop", "Phone No"))
        self.billing.setText(_translate("shop", "BILLING"))
        self.date.setText(_translate("shop", "Date"))
        self.billpr.setText(_translate("shop", "Pr_Id"))
        self.billname.setText(_translate("shop", "Pr_Name"))
        self.quantity.setText(_translate("shop", "QTY"))
        self.billprice.setText(_translate("shop", "Price"))
        self.additem.setText(_translate("shop", "+"))
        self.totalitem.setText(_translate("shop", "New"))
        self.add1item.setText(_translate("shop", "ADD MORE"))
        self.grandtotal.setText(_translate("shop", "GRAND TOTAL"))
        self.billback.clicked.connect(lambda: self.mainwidget.setCurrentIndex(1))
        self.inventBack.clicked.connect(lambda: self.mainwidget.setCurrentIndex(1))
        self.BILLbutton.clicked.connect(lambda: self.mainwidget.setCurrentIndex(3))
        self.INVENTORYbutton.clicked.connect(lambda: self.mainwidget.setCurrentIndex(2))
        self.pushButton.clicked.connect(self.logout)
        self.LOGINButton.clicked.connect(self.admin)
        self.addinvent.clicked.connect(self.add)
        self.loadinvent.clicked.connect(self.inventLoad)
        self.totalitem.clicked.connect(self.handleButton)
        #self.totalitem.clicked.connect(self.save)
        self.additem.clicked.connect(self.load12)
        self.add1item.clicked.connect(self.addmore)
        self.updateinvent.clicked.connect(self.update)
        self.deleteinvent.clicked.connect(self.delete)
######################################################################################################
    def admin(self):
        user=self.userline.text()
        password=self.passline.text()
        if (user == 'aamir' and  password=="aamir123"):
            self.mainwidget.setCurrentIndex(1)
            QMessageBox.information(QMessageBox(),'Successful','AAMIR YOU ARE SUCCESSFULLY LOGGED IN')
        elif (user == 'sajjad' and  password=="sajjad123"):
                self.mainwidget.setCurrentIndex(1)
                QMessageBox.information(QMessageBox(),'Successful','SAJJAD YOU ARE SUCCESSFULLY LOGGED IN')
        elif (user == 'junaid' and  password=="juju9439"):
                self.mainwidget.setCurrentIndex(1)
                QMessageBox.information(QMessageBox(),'Successful','JUNAID YOU ARE SUCCESSFULLY LOGGED IN') 
        else:
            QMessageBox.information(QMessageBox(),'NotSuccessful','Incorrect Passwword or ID')
            self.userline.setText("")
            self.passline.setText("")
######################################################################################################

######################################################################################################

    def add(self):
        Pr_Id=self.pridline.text()
        Pr_Name=self.nameline.text()
        Quantity=self.quanline.text()
        Price=self.costline.text()
        try:
            self.conn = sqlite3.connect("shoesexpress.db")
            self.c = self.conn.cursor()
            self.c.execute("INSERT INTO INVENTORY(PR_ID,PR_NAME,Quantity,Price) VALUES (?,?,?,?)",(Pr_Id,Pr_Name,Quantity,Price))
            self.conn.commit()
            self.pridline.setText("")
            self.quanline.setText("")
            self.nameline.setText("")
            self.costline.setText("")
            QMessageBox.information(QMessageBox(),'Successful','Product is added successfully to the Inventory :).')
            self.conn.close()
        except:
            QMessageBox.information(QMessageBox(),'UnSuccessful','Product is not added successfully to the Inventory :).')
    def update(self):
        Pr_Id=self.pridline.text()
        Quantity=self.quanline.text()
        try:
            self.conn=sqlite3.connect("shoesexpress.db")
            self.c=self.conn.cursor()
            self.c.execute('''UPDATE INVENTORY SET Quantity = ? WHERE PR_ID = ?''', (Quantity, Pr_Id))
            self.conn.commit()
            self.pridline.setText("")
            self.quanline.setText("")
            QMessageBox.information(QMessageBox(),'Successful','Inventory Updated :).')
        except Exception as error:
            QMessageBox.information(QMessageBox(),'Successful','WRONG INFO CHECK AGAIN :).')
    def delete(self):
        Pr_Id=self.pridline.text()
        try:
            self.conn=sqlite3.connect("shoesexpress.db")
            self.c=self.conn.cursor()
            self.c.execute("""DELETE FROM INVENTORY WHERE PR_ID=?""",(Pr_Id))
            self.conn.commit()
            self.pridline.setText("")
        except Exception as error:
            print(error)
#############################################################################################################
    def inventLoad(self):
        try:
            conn=sqlite3.connect("shoesexpress.db")
            mycursor=conn.cursor()
            sql="SELECT * FROM INVENTORY"
            result=mycursor.execute(sql)
        
            self.inventorytable.setRowCount(0)
            for row_num,row_data in enumerate(result):
                self.inventorytable.insertRow(row_num)
                for col_num,col_data in enumerate(row_data):
                    self.inventorytable.setItem(row_num,col_num,QtWidgets.QTableWidgetItem(str(col_data)))        
        except Exception as error:
            print (error)
###############################################################################################################
    def logout(self):
        QMessageBox.information(QMessageBox(),'Successful','SUCCESSFULLY LOGGED OUT ALLAH HAFIZ ')
        self.mainwidget.setCurrentIndex(0)
#############################################################################
   # def save(self):
        
    def handleButton(self):
        global sum1
        price=sum1
        pname=self.billnameedit.text()
        billno=self.billedit.text()
        cusname=self.cusedit.text()
        date=self.dateedit.text()
        address=self.addressedit.text()
        phone=self.phoneedit.text()
        try:
            self.conn = sqlite3.connect("shoesexpress.db")
            self.c = self.conn.cursor()
            self.c.execute("INSERT INTO SALES(BILLNO,PNAME,CUSTOMERNAME,DATE,PRICE,ADDRESS,PHONE) VALUES (?,?,?,?,?,?,?)",(billno,pname,cusname,date,price,address,phone))
            self.conn.commit()
            self.conn.close()
            self.billedit.setText("")
            self.cusedit.setText("")
            self.dateedit.setText("")
            self.grandedit.setText("")
            self.addressedit.setText("")
            self.billnameedit.setText("")
            self.phoneedit.setText("")
        except Exception as error:
            print(error)
        sum1=0
    def load12(self):
        try:
            conn=sqlite3.connect("shoesexpress.db")
            mycursor=conn.cursor()
            x=self.billpredit.text()
            sql="SELECT PR_NAME,Price FROM INVENTORY WHERE PR_ID=?"
            mycursor.execute(sql,(x,))
            x=mycursor.fetchall()
            line=list(x[0])
            self.billnameedit.setText(line[0])
            self.billpriceedit.setText(line[1])
        except Exception as error:
             QMessageBox.information(QMessageBox(),'NOT Successful','BHARWE PHELE PR ID DAL ')       
###########################################################################################
    def addmore(self):
        x=self.billpredit.text()
        x1=self.quantityedit.text()
        x2=self.billpriceedit.text()
        if x1=="" or x2=="":
            QMessageBox.information(QMessageBox(),'Alert','Quantity or Cost unit missing')
        else:
            try:
                conn=sqlite3.connect("shoesexpress.db")
                mycursor=conn.cursor()
                sql=("UPDATE INVENTORY SET Quantity = Quantity - ? WHERE PR_ID = ?")
                mycursor.execute(sql,(x1,x))
                conn.commit()
                A=int(x1)*int(x2)
                global sum1
                sum1=sum1+A
                self.grandedit.setText(str(sum1))
                self.billpredit.setText("")
                self.billpriceedit.setText("")
                self.quantityedit.setText("")
            except Exception as error:
                print(error)
    #########################################################################



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    shop = QtWidgets.QMainWindow()
    ui = Ui_shop()
    ui.setupUi(shop)
    shop.show()
    sys.exit(app.exec_())


# In[ ]:





# In[ ]:




